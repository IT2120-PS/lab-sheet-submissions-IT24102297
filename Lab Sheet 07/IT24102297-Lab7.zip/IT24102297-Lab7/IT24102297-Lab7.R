setwd("C:\\Users\\CNN COMPUTERS\\Desktop\\IT24102297-Lab7")

# Question 1
lower_bound <- 10 
upper_bound <- 25  
total_interval <- 40  
prob_q1 <- (upper_bound - lower_bound) / total_interval
cat("Probability that train arrives between 8:10 a.m. and 8:25 a.m.:", prob_q1, "\n")

# Question 2
lambda <- 1/3
t <- 2  # Time in hours
prob_q2 <- pexp(t, rate = lambda)  # P(X <= 2)
cat("Probability that software update takes at most 2 hours:", prob_q2, "\n")

# Question 3
mean_iq <- 100
sd_iq <- 15

# Part i
prob_q3i <- 1 - pnorm(130, mean = mean_iq, sd = sd_iq)
cat("Probability that IQ is above 130:", prob_q3i, "\n")

# Part ii
percentile_95 <- qnorm(0.95, mean = mean_iq, sd = sd_iq)
cat("IQ score at the 95th percentile:", percentile_95, "\n")
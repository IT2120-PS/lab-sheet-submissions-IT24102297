#Question1
setwd("C:\\Users\\it24102297\\Desktop\\IT24102297")
branch_data <- read.table("Exercise.txt", header =TRUE, sep=",")

#Question2
str(branch_data)

#Question3
boxplot(branch_data$Sales_X1,outline=TRUE, main="Boxplot of Sales", ylab="Sales")

#Question4
summary(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

#Question5
find_outliners <- function(x){
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  iqr <- Q3 - Q1
  
  lower_bound <- Q1 - 1.5 *iqr
  upper_bound <- Q1 + 1.5 *iqr
  
  outliners <- x[x<lower_bound | x>upper_bound]
  
}
find_outliners(branch_data$Years)
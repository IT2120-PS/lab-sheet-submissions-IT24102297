setwd("C:\\Users\\CNN COMPUTERS\\Desktop\\IT24102297")

# Q1

# Parameters
n <- 50         # number of students
p <- 0.85       # probability of passing

# (i) Distribution of X
cat("Q1 (i) Distribution of X: X ~ Binomial(n=50, p=0.85)\n\n")

# (ii) Probability that at least 47 students passed
prob_atleast47 <- sum(dbinom(47:50, size=n, prob=p))
cat("Q1 (ii) Probability that at least 47 students passed =", prob_atleast47, "\n\n")


# Q2

# Parameters
lambda <- 12    # average calls per hour

# (i) Random variable
cat("Q2 (i) Random Variable: X = Number of calls received in one hour\n\n")

# (ii) Distribution of X
cat("Q2 (ii) Distribution of X: X ~ Poisson(lambda=12)\n\n")

# (iii) Probability that exactly 15 calls are received
prob_15 <- dpois(15, lambda=lambda)
cat("Q2 (iii) Probability of exactly 15 calls =", prob_15, "\n\n")


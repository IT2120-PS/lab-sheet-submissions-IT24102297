setwd("C:\\Users\\CNN COMPUTERS\\Desktop\\IT24102297-Lab9")

# Set seed for reproducibility 
set.seed(123)

# i. Generate a random sample of size 25 
data <- rnorm(25, mean = 45, sd = 2)
print(data)   # print generated sample

# ii. Perform test
result <- t.test(data, mu = 46, alternative = "less")

print(result)

test_statistic <- result$statistic   
p_value <- result$p.value           
confidence_interval <- result$conf.int   


cat("Test Statistic (t):", test_statistic, "\n")
cat("P-value:", p_value, "\n")
cat("95% Confidence Interval:", confidence_interval, "\n")


setwd("C:\\Users\\CNN COMPUTERS\\Desktop\\IT24102297-Lab8")

weights <- read.table("Exercise - LaptopsWeights.txt", header = TRUE)

#Extracting numeric collums
weights <- weights[[1]]
cat("Laptop bag weights:\n")
print(weights)

# Q1 population mean and population standard deviation
pop_mean <- mean(weights)
pop_sd <- sd(weights)

cat("\nPopulation Mean:", pop_mean, "\n")
cat("Population Standard Deviation:", pop_sd, "\n")

# Q2 Draw 25 random samples of size 6 (with replacement)
set.seed(123)  
n_samples <- 25
sample_size <- 6

sample_means <- numeric(n_samples)
sample_sds <- numeric(n_samples)

for (i in 1:n_samples) {
  sample_i <- sample(weights, size = sample_size, replace = TRUE)
  sample_means[i] <- mean(sample_i)
  sample_sds[i] <- sd(sample_i)
  cat("\nSample", i, "Mean =", sample_means[i], " | SD =", sample_sds[i])
}

# Q3 Calculate mean and SD of the 25 sample means
mean_of_sample_means <- mean(sample_means)
sd_of_sample_means <- sd(sample_means)

cat("\n\nMean of Sample Means:", mean_of_sample_means, "\n")
cat("SD of Sample Means:", sd_of_sample_means, "\n")

# Relationship
cat(" The mean of the sample means is approximately equal to the population mean")
    
